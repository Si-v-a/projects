from django.contrib import admin
from django.urls import path,include
from . import views
urlpatterns = [
    path('',views.index,name="index_page"),
    path("insert/", views.insetdata, name="insert"),
    path('showpage/', views.showpage, name='showpage'),
    path('show_data/',views.show_data,name="show_data"),
    path('show_sequential_data/',views.show_sequential_data,name="show_sequential_data"),
    path('search_data/',views.search_data,name="search_data"),
    path('search_specific_date/',views.search_specific_date,name="search_specific_date"),

]