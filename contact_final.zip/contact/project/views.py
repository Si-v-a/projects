from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Submission
from django.utils import timezone
# Create your views here.

from django.contrib import messages
from datetime import datetime
from django.core.exceptions import ValidationError
def index(request):
    return render(request, 'index.html')



def insetdata(request):
    if request.method == 'POST':
        name = request.POST.get("names")
        number = request.POST.get("number")
        date = request.POST.get("date")
        next_followup_date = request.POST.get("Next-Followup-date")
        additional_data = request.POST.get("name")  # Ensure this matches your form input name

        # Validation for number
        if not number.isdigit() or len(number) != 10:
            return render(request, 'error.html', {'message': 'The number must be exactly 10 digits.'})

        if Submission.objects.filter(number=number).exists():
            return render(request, 'error.html', {'message': 'The number must be unique.'})

        # Validation for date
        try:
            date_obj = datetime.strptime(date, '%Y-%m-%d')
            if date_obj.date() < datetime.now().date():
                return render(request, 'error.html', {'message': 'The date must not be in the past.'})
        except ValueError:
            return render(request, 'error.html', {'message': 'Invalid date format. Use YYYY-MM-DD.'})

        # Validation for next_followup_date
        try:
            next_followup_date_obj = datetime.strptime(next_followup_date, '%Y-%m-%d')
            if next_followup_date_obj.date() <= datetime.now().date():
                return render(request, 'error.html', {'message': 'Next follow-up date must be in the future.'})
        except ValueError:
            return render(request, 'error.html', {'message': 'Invalid follow-up date format. Use YYYY-MM-DD.'})

        # Create a new Submission instance
        yaleit = Submission.objects.create(
            name=name,
            number=number,
            date=date_obj,
            next_followup_date=next_followup_date_obj,
            additional_data=additional_data,
        )
        yaleit.save()
        return redirect("showpage")

    return render(request, 'index.html')


def showpage(request):
    return render(request,"show.html")

def show_data(request):
    all_data = Submission.objects.all()
    return render(request,"show_data.html",{"key1":all_data})

def show_sequential_data(request):
    all_data = Submission.objects.all().order_by('next_followup_date')
    return render(request, "show_sequential_data.html", {"key1": all_data})


def search_data(request):
    return render(request,"search_data.html")
    """
    today = timezone.now().date()
    all_data = Submission.objects.filter(next_followup_date=today).order_by('next_followup_date')
    return render(request, "show_data.html", {"key1": all_data})
"""

def search_specific_date(request):
    if request.method == 'POST':
        search_date = request.POST.get('search_date')  # Get the date from the form
        submissions = Submission.objects.filter(next_followup_date=search_date)  # Filter submissions by the date

        return render(request, 'search_results.html', {"key1":submissions })

    return HttpResponse("Invalid request", status=400)





